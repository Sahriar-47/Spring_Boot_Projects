package com.example.weather_app.controller;

import com.example.weather_app.model.WeatherResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class WeatherController {
    @Value("${api.key}")
    private String apikey;
    @GetMapping("/abc")
    public String getindex(){
        return "index";
    }
    @GetMapping("/weather")
    public String getweather(@RequestParam("city") String city, Model model){
        String url = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apikey + "&units=metric";
        RestTemplate restTemplate = new RestTemplate();
        WeatherResponse weatherResponse = restTemplate.getForObject(url,WeatherResponse.class);
        System.out.println(weatherResponse);

        if(weatherResponse != null){
            model.addAttribute("city", weatherResponse.getName());
            model.addAttribute("country", weatherResponse.getSys().getCountry());
            model.addAttribute("weatherDescription", weatherResponse.getWeather().get(0).getDescription());
            model.addAttribute("temperature", weatherResponse.getMain().getTemp());
            model.addAttribute("humidity", weatherResponse.getMain().getHumidity());
            model.addAttribute("windspeed", weatherResponse.getWind().getSpeed());
            String weatherIcon = "wi wi-own-" + weatherResponse.getWeather().get(0).getId();
            model.addAttribute("weatherIcon",weatherIcon);
        }
        else{
            model.addAttribute("error","city not foun");
        }
        return "weather";
    }
    @PostMapping("/weather")
    public String postweather(@RequestParam("city") String city, Model model){
        return "redirect:/weather?city=" + city;
    }


    @GetMapping("/index")
    public String getHomepage(){
        return "index";
    }
}


