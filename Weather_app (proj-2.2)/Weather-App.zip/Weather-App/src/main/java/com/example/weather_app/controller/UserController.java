package com.example.weather_app.controller;

import com.example.weather_app.model.User;
import com.example.weather_app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public ModelAndView loginPage(@RequestParam(value = "error", required = false) String error) {
        ModelAndView mav = new ModelAndView("login");
        if (error != null) {
            mav.addObject("errorMessage", "Invalid email or password");
        }
        return mav;
    }

    @PostMapping("/login")
    public ModelAndView loginUser(@RequestParam String email,
                                  @RequestParam String password) {
        ModelAndView mav = new ModelAndView();
        User user = userService.getUserByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
//            session.setAttribute("user", user);
            System.out.println(user.toString());

            mav.setViewName("redirect:/index");
        } else {
            mav.setViewName("redirect:/login?error=true");
        }
        return mav;
    }

    @GetMapping("/register")
    public ModelAndView registerPage() {
        return new ModelAndView("register");
    }

    @PostMapping("/register")
    public ModelAndView registerUser(@RequestParam String email,
                                     @RequestParam String password,
                                     @RequestParam String nickname) {
        userService.registerUser(email, password, nickname);
        return new ModelAndView("redirect:/login");
    }
}
