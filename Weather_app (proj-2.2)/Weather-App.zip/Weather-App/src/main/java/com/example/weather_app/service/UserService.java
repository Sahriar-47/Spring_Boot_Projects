package com.example.weather_app.service;

import com.example.weather_app.model.User;
import com.example.weather_app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(String email, String password, String nickname) {
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);    // <-- add password
        user.setNickname(nickname);
        return userRepository.save(user);
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}
