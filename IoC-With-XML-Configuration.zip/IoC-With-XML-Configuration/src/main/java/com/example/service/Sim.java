package com.example.service;

public interface Sim {
    void calling();
    void data();
}
